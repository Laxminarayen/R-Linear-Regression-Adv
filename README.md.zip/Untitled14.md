

```R
#library(magrittr)
#library(caret)
#library(dplyr)
A <- read.csv("E://housetrain.csv")
colSums(is.na(A))
str(A)
A <- A[,-c(7,58,73,74,75)]
colSums(is.na(A))
A <- na.omit(A)
d <- createDataPartition(A$SalePrice,p =0.9,list = FALSE) %>% c()
train <- A[d,]
test <- A[-d,]
model5 <- lm(SalePrice~OverallQual+YearBuilt+YearRemodAdd+TotalBsmtSF+GrLivArea+FullBath+GarageCars,A)
summary(model5)
colnames(A)
f <- predict(model5,test)
RMSE(f,test$SalePrice)
plot(model5)

```


<dl class=dl-horizontal>
	<dt>Id</dt>
		<dd>0</dd>
	<dt>MSSubClass</dt>
		<dd>0</dd>
	<dt>MSZoning</dt>
		<dd>0</dd>
	<dt>LotFrontage</dt>
		<dd>259</dd>
	<dt>LotArea</dt>
		<dd>0</dd>
	<dt>Street</dt>
		<dd>0</dd>
	<dt>Alley</dt>
		<dd>1369</dd>
	<dt>LotShape</dt>
		<dd>0</dd>
	<dt>LandContour</dt>
		<dd>0</dd>
	<dt>Utilities</dt>
		<dd>0</dd>
	<dt>LotConfig</dt>
		<dd>0</dd>
	<dt>LandSlope</dt>
		<dd>0</dd>
	<dt>Neighborhood</dt>
		<dd>0</dd>
	<dt>Condition1</dt>
		<dd>0</dd>
	<dt>Condition2</dt>
		<dd>0</dd>
	<dt>BldgType</dt>
		<dd>0</dd>
	<dt>HouseStyle</dt>
		<dd>0</dd>
	<dt>OverallQual</dt>
		<dd>0</dd>
	<dt>OverallCond</dt>
		<dd>0</dd>
	<dt>YearBuilt</dt>
		<dd>0</dd>
	<dt>YearRemodAdd</dt>
		<dd>0</dd>
	<dt>RoofStyle</dt>
		<dd>0</dd>
	<dt>RoofMatl</dt>
		<dd>0</dd>
	<dt>Exterior1st</dt>
		<dd>0</dd>
	<dt>Exterior2nd</dt>
		<dd>0</dd>
	<dt>MasVnrType</dt>
		<dd>8</dd>
	<dt>MasVnrArea</dt>
		<dd>8</dd>
	<dt>ExterQual</dt>
		<dd>0</dd>
	<dt>ExterCond</dt>
		<dd>0</dd>
	<dt>Foundation</dt>
		<dd>0</dd>
	<dt>BsmtQual</dt>
		<dd>37</dd>
	<dt>BsmtCond</dt>
		<dd>37</dd>
	<dt>BsmtExposure</dt>
		<dd>38</dd>
	<dt>BsmtFinType1</dt>
		<dd>37</dd>
	<dt>BsmtFinSF1</dt>
		<dd>0</dd>
	<dt>BsmtFinType2</dt>
		<dd>38</dd>
	<dt>BsmtFinSF2</dt>
		<dd>0</dd>
	<dt>BsmtUnfSF</dt>
		<dd>0</dd>
	<dt>TotalBsmtSF</dt>
		<dd>0</dd>
	<dt>Heating</dt>
		<dd>0</dd>
	<dt>HeatingQC</dt>
		<dd>0</dd>
	<dt>CentralAir</dt>
		<dd>0</dd>
	<dt>Electrical</dt>
		<dd>1</dd>
	<dt>X1stFlrSF</dt>
		<dd>0</dd>
	<dt>X2ndFlrSF</dt>
		<dd>0</dd>
	<dt>LowQualFinSF</dt>
		<dd>0</dd>
	<dt>GrLivArea</dt>
		<dd>0</dd>
	<dt>BsmtFullBath</dt>
		<dd>0</dd>
	<dt>BsmtHalfBath</dt>
		<dd>0</dd>
	<dt>FullBath</dt>
		<dd>0</dd>
	<dt>HalfBath</dt>
		<dd>0</dd>
	<dt>BedroomAbvGr</dt>
		<dd>0</dd>
	<dt>KitchenAbvGr</dt>
		<dd>0</dd>
	<dt>KitchenQual</dt>
		<dd>0</dd>
	<dt>TotRmsAbvGrd</dt>
		<dd>0</dd>
	<dt>Functional</dt>
		<dd>0</dd>
	<dt>Fireplaces</dt>
		<dd>0</dd>
	<dt>FireplaceQu</dt>
		<dd>690</dd>
	<dt>GarageType</dt>
		<dd>81</dd>
	<dt>GarageYrBlt</dt>
		<dd>81</dd>
	<dt>GarageFinish</dt>
		<dd>81</dd>
	<dt>GarageCars</dt>
		<dd>0</dd>
	<dt>GarageArea</dt>
		<dd>0</dd>
	<dt>GarageQual</dt>
		<dd>81</dd>
	<dt>GarageCond</dt>
		<dd>81</dd>
	<dt>PavedDrive</dt>
		<dd>0</dd>
	<dt>WoodDeckSF</dt>
		<dd>0</dd>
	<dt>OpenPorchSF</dt>
		<dd>0</dd>
	<dt>EnclosedPorch</dt>
		<dd>0</dd>
	<dt>X3SsnPorch</dt>
		<dd>0</dd>
	<dt>ScreenPorch</dt>
		<dd>0</dd>
	<dt>PoolArea</dt>
		<dd>0</dd>
	<dt>PoolQC</dt>
		<dd>1453</dd>
	<dt>Fence</dt>
		<dd>1179</dd>
	<dt>MiscFeature</dt>
		<dd>1406</dd>
	<dt>MiscVal</dt>
		<dd>0</dd>
	<dt>MoSold</dt>
		<dd>0</dd>
	<dt>YrSold</dt>
		<dd>0</dd>
	<dt>SaleType</dt>
		<dd>0</dd>
	<dt>SaleCondition</dt>
		<dd>0</dd>
	<dt>SalePrice</dt>
		<dd>0</dd>
</dl>



    'data.frame':	1460 obs. of  81 variables:
     $ Id           : int  1 2 3 4 5 6 7 8 9 10 ...
     $ MSSubClass   : int  60 20 60 70 60 50 20 60 50 190 ...
     $ MSZoning     : Factor w/ 5 levels "C (all)","FV",..: 4 4 4 4 4 4 4 4 5 4 ...
     $ LotFrontage  : int  65 80 68 60 84 85 75 NA 51 50 ...
     $ LotArea      : int  8450 9600 11250 9550 14260 14115 10084 10382 6120 7420 ...
     $ Street       : Factor w/ 2 levels "Grvl","Pave": 2 2 2 2 2 2 2 2 2 2 ...
     $ Alley        : Factor w/ 2 levels "Grvl","Pave": NA NA NA NA NA NA NA NA NA NA ...
     $ LotShape     : Factor w/ 4 levels "IR1","IR2","IR3",..: 4 4 1 1 1 1 4 1 4 4 ...
     $ LandContour  : Factor w/ 4 levels "Bnk","HLS","Low",..: 4 4 4 4 4 4 4 4 4 4 ...
     $ Utilities    : Factor w/ 2 levels "AllPub","NoSeWa": 1 1 1 1 1 1 1 1 1 1 ...
     $ LotConfig    : Factor w/ 5 levels "Corner","CulDSac",..: 5 3 5 1 3 5 5 1 5 1 ...
     $ LandSlope    : Factor w/ 3 levels "Gtl","Mod","Sev": 1 1 1 1 1 1 1 1 1 1 ...
     $ Neighborhood : Factor w/ 25 levels "Blmngtn","Blueste",..: 6 25 6 7 14 12 21 17 18 4 ...
     $ Condition1   : Factor w/ 9 levels "Artery","Feedr",..: 3 2 3 3 3 3 3 5 1 1 ...
     $ Condition2   : Factor w/ 8 levels "Artery","Feedr",..: 3 3 3 3 3 3 3 3 3 1 ...
     $ BldgType     : Factor w/ 5 levels "1Fam","2fmCon",..: 1 1 1 1 1 1 1 1 1 2 ...
     $ HouseStyle   : Factor w/ 8 levels "1.5Fin","1.5Unf",..: 6 3 6 6 6 1 3 6 1 2 ...
     $ OverallQual  : int  7 6 7 7 8 5 8 7 7 5 ...
     $ OverallCond  : int  5 8 5 5 5 5 5 6 5 6 ...
     $ YearBuilt    : int  2003 1976 2001 1915 2000 1993 2004 1973 1931 1939 ...
     $ YearRemodAdd : int  2003 1976 2002 1970 2000 1995 2005 1973 1950 1950 ...
     $ RoofStyle    : Factor w/ 6 levels "Flat","Gable",..: 2 2 2 2 2 2 2 2 2 2 ...
     $ RoofMatl     : Factor w/ 8 levels "ClyTile","CompShg",..: 2 2 2 2 2 2 2 2 2 2 ...
     $ Exterior1st  : Factor w/ 15 levels "AsbShng","AsphShn",..: 13 9 13 14 13 13 13 7 4 9 ...
     $ Exterior2nd  : Factor w/ 16 levels "AsbShng","AsphShn",..: 14 9 14 16 14 14 14 7 16 9 ...
     $ MasVnrType   : Factor w/ 4 levels "BrkCmn","BrkFace",..: 2 3 2 3 2 3 4 4 3 3 ...
     $ MasVnrArea   : int  196 0 162 0 350 0 186 240 0 0 ...
     $ ExterQual    : Factor w/ 4 levels "Ex","Fa","Gd",..: 3 4 3 4 3 4 3 4 4 4 ...
     $ ExterCond    : Factor w/ 5 levels "Ex","Fa","Gd",..: 5 5 5 5 5 5 5 5 5 5 ...
     $ Foundation   : Factor w/ 6 levels "BrkTil","CBlock",..: 3 2 3 1 3 6 3 2 1 1 ...
     $ BsmtQual     : Factor w/ 4 levels "Ex","Fa","Gd",..: 3 3 3 4 3 3 1 3 4 4 ...
     $ BsmtCond     : Factor w/ 4 levels "Fa","Gd","Po",..: 4 4 4 2 4 4 4 4 4 4 ...
     $ BsmtExposure : Factor w/ 4 levels "Av","Gd","Mn",..: 4 2 3 4 1 4 1 3 4 4 ...
     $ BsmtFinType1 : Factor w/ 6 levels "ALQ","BLQ","GLQ",..: 3 1 3 1 3 3 3 1 6 3 ...
     $ BsmtFinSF1   : int  706 978 486 216 655 732 1369 859 0 851 ...
     $ BsmtFinType2 : Factor w/ 6 levels "ALQ","BLQ","GLQ",..: 6 6 6 6 6 6 6 2 6 6 ...
     $ BsmtFinSF2   : int  0 0 0 0 0 0 0 32 0 0 ...
     $ BsmtUnfSF    : int  150 284 434 540 490 64 317 216 952 140 ...
     $ TotalBsmtSF  : int  856 1262 920 756 1145 796 1686 1107 952 991 ...
     $ Heating      : Factor w/ 6 levels "Floor","GasA",..: 2 2 2 2 2 2 2 2 2 2 ...
     $ HeatingQC    : Factor w/ 5 levels "Ex","Fa","Gd",..: 1 1 1 3 1 1 1 1 3 1 ...
     $ CentralAir   : Factor w/ 2 levels "N","Y": 2 2 2 2 2 2 2 2 2 2 ...
     $ Electrical   : Factor w/ 5 levels "FuseA","FuseF",..: 5 5 5 5 5 5 5 5 2 5 ...
     $ X1stFlrSF    : int  856 1262 920 961 1145 796 1694 1107 1022 1077 ...
     $ X2ndFlrSF    : int  854 0 866 756 1053 566 0 983 752 0 ...
     $ LowQualFinSF : int  0 0 0 0 0 0 0 0 0 0 ...
     $ GrLivArea    : int  1710 1262 1786 1717 2198 1362 1694 2090 1774 1077 ...
     $ BsmtFullBath : int  1 0 1 1 1 1 1 1 0 1 ...
     $ BsmtHalfBath : int  0 1 0 0 0 0 0 0 0 0 ...
     $ FullBath     : int  2 2 2 1 2 1 2 2 2 1 ...
     $ HalfBath     : int  1 0 1 0 1 1 0 1 0 0 ...
     $ BedroomAbvGr : int  3 3 3 3 4 1 3 3 2 2 ...
     $ KitchenAbvGr : int  1 1 1 1 1 1 1 1 2 2 ...
     $ KitchenQual  : Factor w/ 4 levels "Ex","Fa","Gd",..: 3 4 3 3 3 4 3 4 4 4 ...
     $ TotRmsAbvGrd : int  8 6 6 7 9 5 7 7 8 5 ...
     $ Functional   : Factor w/ 7 levels "Maj1","Maj2",..: 7 7 7 7 7 7 7 7 3 7 ...
     $ Fireplaces   : int  0 1 1 1 1 0 1 2 2 2 ...
     $ FireplaceQu  : Factor w/ 5 levels "Ex","Fa","Gd",..: NA 5 5 3 5 NA 3 5 5 5 ...
     $ GarageType   : Factor w/ 6 levels "2Types","Attchd",..: 2 2 2 6 2 2 2 2 6 2 ...
     $ GarageYrBlt  : int  2003 1976 2001 1998 2000 1993 2004 1973 1931 1939 ...
     $ GarageFinish : Factor w/ 3 levels "Fin","RFn","Unf": 2 2 2 3 2 3 2 2 3 2 ...
     $ GarageCars   : int  2 2 2 3 3 2 2 2 2 1 ...
     $ GarageArea   : int  548 460 608 642 836 480 636 484 468 205 ...
     $ GarageQual   : Factor w/ 5 levels "Ex","Fa","Gd",..: 5 5 5 5 5 5 5 5 2 3 ...
     $ GarageCond   : Factor w/ 5 levels "Ex","Fa","Gd",..: 5 5 5 5 5 5 5 5 5 5 ...
     $ PavedDrive   : Factor w/ 3 levels "N","P","Y": 3 3 3 3 3 3 3 3 3 3 ...
     $ WoodDeckSF   : int  0 298 0 0 192 40 255 235 90 0 ...
     $ OpenPorchSF  : int  61 0 42 35 84 30 57 204 0 4 ...
     $ EnclosedPorch: int  0 0 0 272 0 0 0 228 205 0 ...
     $ X3SsnPorch   : int  0 0 0 0 0 320 0 0 0 0 ...
     $ ScreenPorch  : int  0 0 0 0 0 0 0 0 0 0 ...
     $ PoolArea     : int  0 0 0 0 0 0 0 0 0 0 ...
     $ PoolQC       : Factor w/ 3 levels "Ex","Fa","Gd": NA NA NA NA NA NA NA NA NA NA ...
     $ Fence        : Factor w/ 4 levels "GdPrv","GdWo",..: NA NA NA NA NA 3 NA NA NA NA ...
     $ MiscFeature  : Factor w/ 4 levels "Gar2","Othr",..: NA NA NA NA NA 3 NA 3 NA NA ...
     $ MiscVal      : int  0 0 0 0 0 700 0 350 0 0 ...
     $ MoSold       : int  2 5 9 2 12 10 8 11 4 1 ...
     $ YrSold       : int  2008 2007 2008 2006 2008 2009 2007 2009 2008 2008 ...
     $ SaleType     : Factor w/ 9 levels "COD","Con","ConLD",..: 9 9 9 9 9 9 9 9 9 9 ...
     $ SaleCondition: Factor w/ 6 levels "Abnorml","AdjLand",..: 5 5 5 1 5 5 5 5 1 5 ...
     $ SalePrice    : int  208500 181500 223500 140000 250000 143000 307000 200000 129900 118000 ...
    


<dl class=dl-horizontal>
	<dt>Id</dt>
		<dd>0</dd>
	<dt>MSSubClass</dt>
		<dd>0</dd>
	<dt>MSZoning</dt>
		<dd>0</dd>
	<dt>LotFrontage</dt>
		<dd>259</dd>
	<dt>LotArea</dt>
		<dd>0</dd>
	<dt>Street</dt>
		<dd>0</dd>
	<dt>LotShape</dt>
		<dd>0</dd>
	<dt>LandContour</dt>
		<dd>0</dd>
	<dt>Utilities</dt>
		<dd>0</dd>
	<dt>LotConfig</dt>
		<dd>0</dd>
	<dt>LandSlope</dt>
		<dd>0</dd>
	<dt>Neighborhood</dt>
		<dd>0</dd>
	<dt>Condition1</dt>
		<dd>0</dd>
	<dt>Condition2</dt>
		<dd>0</dd>
	<dt>BldgType</dt>
		<dd>0</dd>
	<dt>HouseStyle</dt>
		<dd>0</dd>
	<dt>OverallQual</dt>
		<dd>0</dd>
	<dt>OverallCond</dt>
		<dd>0</dd>
	<dt>YearBuilt</dt>
		<dd>0</dd>
	<dt>YearRemodAdd</dt>
		<dd>0</dd>
	<dt>RoofStyle</dt>
		<dd>0</dd>
	<dt>RoofMatl</dt>
		<dd>0</dd>
	<dt>Exterior1st</dt>
		<dd>0</dd>
	<dt>Exterior2nd</dt>
		<dd>0</dd>
	<dt>MasVnrType</dt>
		<dd>8</dd>
	<dt>MasVnrArea</dt>
		<dd>8</dd>
	<dt>ExterQual</dt>
		<dd>0</dd>
	<dt>ExterCond</dt>
		<dd>0</dd>
	<dt>Foundation</dt>
		<dd>0</dd>
	<dt>BsmtQual</dt>
		<dd>37</dd>
	<dt>BsmtCond</dt>
		<dd>37</dd>
	<dt>BsmtExposure</dt>
		<dd>38</dd>
	<dt>BsmtFinType1</dt>
		<dd>37</dd>
	<dt>BsmtFinSF1</dt>
		<dd>0</dd>
	<dt>BsmtFinType2</dt>
		<dd>38</dd>
	<dt>BsmtFinSF2</dt>
		<dd>0</dd>
	<dt>BsmtUnfSF</dt>
		<dd>0</dd>
	<dt>TotalBsmtSF</dt>
		<dd>0</dd>
	<dt>Heating</dt>
		<dd>0</dd>
	<dt>HeatingQC</dt>
		<dd>0</dd>
	<dt>CentralAir</dt>
		<dd>0</dd>
	<dt>Electrical</dt>
		<dd>1</dd>
	<dt>X1stFlrSF</dt>
		<dd>0</dd>
	<dt>X2ndFlrSF</dt>
		<dd>0</dd>
	<dt>LowQualFinSF</dt>
		<dd>0</dd>
	<dt>GrLivArea</dt>
		<dd>0</dd>
	<dt>BsmtFullBath</dt>
		<dd>0</dd>
	<dt>BsmtHalfBath</dt>
		<dd>0</dd>
	<dt>FullBath</dt>
		<dd>0</dd>
	<dt>HalfBath</dt>
		<dd>0</dd>
	<dt>BedroomAbvGr</dt>
		<dd>0</dd>
	<dt>KitchenAbvGr</dt>
		<dd>0</dd>
	<dt>KitchenQual</dt>
		<dd>0</dd>
	<dt>TotRmsAbvGrd</dt>
		<dd>0</dd>
	<dt>Functional</dt>
		<dd>0</dd>
	<dt>Fireplaces</dt>
		<dd>0</dd>
	<dt>GarageType</dt>
		<dd>81</dd>
	<dt>GarageYrBlt</dt>
		<dd>81</dd>
	<dt>GarageFinish</dt>
		<dd>81</dd>
	<dt>GarageCars</dt>
		<dd>0</dd>
	<dt>GarageArea</dt>
		<dd>0</dd>
	<dt>GarageQual</dt>
		<dd>81</dd>
	<dt>GarageCond</dt>
		<dd>81</dd>
	<dt>PavedDrive</dt>
		<dd>0</dd>
	<dt>WoodDeckSF</dt>
		<dd>0</dd>
	<dt>OpenPorchSF</dt>
		<dd>0</dd>
	<dt>EnclosedPorch</dt>
		<dd>0</dd>
	<dt>X3SsnPorch</dt>
		<dd>0</dd>
	<dt>ScreenPorch</dt>
		<dd>0</dd>
	<dt>PoolArea</dt>
		<dd>0</dd>
	<dt>MiscVal</dt>
		<dd>0</dd>
	<dt>MoSold</dt>
		<dd>0</dd>
	<dt>YrSold</dt>
		<dd>0</dd>
	<dt>SaleType</dt>
		<dd>0</dd>
	<dt>SaleCondition</dt>
		<dd>0</dd>
	<dt>SalePrice</dt>
		<dd>0</dd>
</dl>




    
    Call:
    lm(formula = SalePrice ~ OverallQual + YearBuilt + YearRemodAdd + 
        TotalBsmtSF + GrLivArea + FullBath + GarageCars, data = A)
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -492148  -20099   -2140   17381  280599 
    
    Coefficients:
                   Estimate Std. Error t value Pr(>|t|)    
    (Intercept)  -1.166e+06  1.594e+05  -7.316 4.96e-13 ***
    OverallQual   2.193e+04  1.512e+03  14.509  < 2e-16 ***
    YearBuilt     2.237e+02  6.193e+01   3.611 0.000318 ***
    YearRemodAdd  3.223e+02  8.065e+01   3.997 6.85e-05 ***
    TotalBsmtSF   2.937e+01  3.803e+00   7.722 2.60e-14 ***
    GrLivArea     5.408e+01  3.719e+00  14.544  < 2e-16 ***
    FullBath     -8.638e+03  3.337e+03  -2.589 0.009768 ** 
    GarageCars    1.759e+04  2.589e+03   6.794 1.79e-11 ***
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 40590 on 1086 degrees of freedom
    Multiple R-squared:  0.7633,	Adjusted R-squared:  0.7618 
    F-statistic: 500.4 on 7 and 1086 DF,  p-value: < 2.2e-16
    



<ol class=list-inline>
	<li>'Id'</li>
	<li>'MSSubClass'</li>
	<li>'MSZoning'</li>
	<li>'LotFrontage'</li>
	<li>'LotArea'</li>
	<li>'Street'</li>
	<li>'LotShape'</li>
	<li>'LandContour'</li>
	<li>'Utilities'</li>
	<li>'LotConfig'</li>
	<li>'LandSlope'</li>
	<li>'Neighborhood'</li>
	<li>'Condition1'</li>
	<li>'Condition2'</li>
	<li>'BldgType'</li>
	<li>'HouseStyle'</li>
	<li>'OverallQual'</li>
	<li>'OverallCond'</li>
	<li>'YearBuilt'</li>
	<li>'YearRemodAdd'</li>
	<li>'RoofStyle'</li>
	<li>'RoofMatl'</li>
	<li>'Exterior1st'</li>
	<li>'Exterior2nd'</li>
	<li>'MasVnrType'</li>
	<li>'MasVnrArea'</li>
	<li>'ExterQual'</li>
	<li>'ExterCond'</li>
	<li>'Foundation'</li>
	<li>'BsmtQual'</li>
	<li>'BsmtCond'</li>
	<li>'BsmtExposure'</li>
	<li>'BsmtFinType1'</li>
	<li>'BsmtFinSF1'</li>
	<li>'BsmtFinType2'</li>
	<li>'BsmtFinSF2'</li>
	<li>'BsmtUnfSF'</li>
	<li>'TotalBsmtSF'</li>
	<li>'Heating'</li>
	<li>'HeatingQC'</li>
	<li>'CentralAir'</li>
	<li>'Electrical'</li>
	<li>'X1stFlrSF'</li>
	<li>'X2ndFlrSF'</li>
	<li>'LowQualFinSF'</li>
	<li>'GrLivArea'</li>
	<li>'BsmtFullBath'</li>
	<li>'BsmtHalfBath'</li>
	<li>'FullBath'</li>
	<li>'HalfBath'</li>
	<li>'BedroomAbvGr'</li>
	<li>'KitchenAbvGr'</li>
	<li>'KitchenQual'</li>
	<li>'TotRmsAbvGrd'</li>
	<li>'Functional'</li>
	<li>'Fireplaces'</li>
	<li>'GarageType'</li>
	<li>'GarageYrBlt'</li>
	<li>'GarageFinish'</li>
	<li>'GarageCars'</li>
	<li>'GarageArea'</li>
	<li>'GarageQual'</li>
	<li>'GarageCond'</li>
	<li>'PavedDrive'</li>
	<li>'WoodDeckSF'</li>
	<li>'OpenPorchSF'</li>
	<li>'EnclosedPorch'</li>
	<li>'X3SsnPorch'</li>
	<li>'ScreenPorch'</li>
	<li>'PoolArea'</li>
	<li>'MiscVal'</li>
	<li>'MoSold'</li>
	<li>'YrSold'</li>
	<li>'SaleType'</li>
	<li>'SaleCondition'</li>
	<li>'SalePrice'</li>
</ol>




51632.9320178911



![png](output_0_6.png)



![png](output_0_7.png)



![png](output_0_8.png)



![png](output_0_9.png)

